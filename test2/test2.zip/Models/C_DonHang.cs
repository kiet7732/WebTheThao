﻿namespace DoAn.Models
{
    public class C_DonHang
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Phone { get; set; }
        public string EmailAddress { get; set; }
        public string Country { get; set; }
        public string Address { get; set; }
        public string Apartment { get; set; }
        public string OrderNotes { get; set; }
        public string PhuongThuc { get; set; }
    }
}